import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin, isErrorResponse } from "@/lib/api-utils";
import * as bcrypt from "bcryptjs";
import { getParcoursTypeForOffer, requiresQuestionnaire as parcoursNeedsQuestionnaire, welcomeVideoForOffer } from "@/lib/offer-parcours-binding";
import { getDefaultsForParcoursType } from "@/lib/parcours-defaults";
import type { ParcoursType } from "@prisma/client";

// POST /api/admin/create-client — Creer un client directement (avec ou sans legacy)
export async function POST(request: NextRequest) {
  const auth = await requireAdmin();
  if (isErrorResponse(auth)) return auth;

  const {
    firstName, lastName, email, offerType, language, isLegacy, startDate, dayDirect,
    parcoursType,
    requiresConvention, requiresQuestionnaire,
    requiresPhaseVideos, requiresMorningCheckin, requiresEveningCheckin,
    requiresJournal, requiresProgramTimeline, requiresElixirs,
  } = await request.json();

  if (!firstName || !lastName || !email) {
    return NextResponse.json({ error: "Prenom, nom et email requis" }, { status: 400 });
  }

  // Normaliser email (lowercase + trim) + validation RFC 5321
  const normalizedEmail = email.toLowerCase().trim();
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(normalizedEmail)) {
    return NextResponse.json({ error: "Format email invalide" }, { status: 400 });
  }

  // Check existing user (case-insensitive)
  const existing = await prisma.user.findFirst({
    where: { email: { equals: normalizedEmail, mode: "insensitive" } },
  });
  if (existing) {
    return NextResponse.json({ error: "Un compte existe deja avec cet email" }, { status: 409 });
  }

  const fullName = `${firstName} ${lastName}`;
  // Generate a random temporary password — client will set it via invite link
  const tempPassword = crypto.randomUUID().slice(0, 12);
  const hashedPassword = await bcrypt.hash(tempPassword, 10);

  // Calculate start date for legacy
  let clientStartDate = new Date();
  if (isLegacy) {
    if (startDate) {
      clientStartDate = new Date(startDate);
    } else if (dayDirect && dayDirect > 0) {
      // Day X means they started X days ago
      clientStartDate = new Date();
      clientStartDate.setDate(clientStartDate.getDate() - (dayDirect - 1));
    }
  }

  // Binding offre → parcours (garde-fou serveur) + defaults flags
  const resolvedOffer = offerType || "CONVERSATION_EXPLORATOIRE";
  const resolvedParcours: ParcoursType =
    typeof parcoursType === "string" && parcoursType
      ? (parcoursType as ParcoursType)
      : getParcoursTypeForOffer(resolvedOffer);
  const parcoursDefaults = getDefaultsForParcoursType(resolvedParcours);

  // Create user + client in transaction
  const user = await prisma.user.create({
    data: {
      email: normalizedEmail,
      password: hashedPassword,
      name: fullName,
      role: "CLIENT",
    },
  });

  const client = await prisma.client.create({
    data: {
      userId: user.id,
      offerType: resolvedOffer,
      language: language || "FR",
      isLegacy: isLegacy || false,
      startDate: clientStartDate,
      // Blocage PWA : onboarding requis seulement si le parcours exige le questionnaire
      // Respecte la case décochée par l'admin (override) sinon défaut du parcours.
      onboardingCompleted: isLegacy
        ? true
        : !(requiresQuestionnaire !== undefined
            ? Boolean(requiresQuestionnaire)
            : parcoursNeedsQuestionnaire(resolvedParcours)),
      parcoursType: resolvedParcours,
      // Flags : défauts du parcours, surchargés par toute valeur fournie explicitement
      ...parcoursDefaults,
      // Vidéo Seuil 1 : forcée par l'offre (jamais éditée par l'admin)
      requiresWelcomeVideo: welcomeVideoForOffer(resolvedOffer),
      ...(requiresConvention !== undefined ? { requiresConvention } : {}),
      ...(requiresQuestionnaire !== undefined ? { requiresQuestionnaire } : {}),
      ...(requiresPhaseVideos !== undefined ? { requiresPhaseVideos } : {}),
      ...(requiresMorningCheckin !== undefined ? { requiresMorningCheckin } : {}),
      ...(requiresEveningCheckin !== undefined ? { requiresEveningCheckin } : {}),
      ...(requiresJournal !== undefined ? { requiresJournal } : {}),
      ...(requiresProgramTimeline !== undefined ? { requiresProgramTimeline } : {}),
      ...(requiresElixirs !== undefined ? { requiresElixirs } : {}),
      ...(isLegacy ? {
        charteSignee: true,
        charteSignedAt: new Date(),
        colisEnvoye: true,
        colisEnvoyeAt: new Date(),
        produitsRecus: true,
        produitsRecusAt: new Date(),
        detoxStartDate: clientStartDate,
      } : {}),
    },
  });

  // Create invite token for the welcome email (so client can set password)
  const expiresAt = new Date();
  expiresAt.setDate(expiresAt.getDate() + 365);

  const inviteToken = await prisma.inviteToken.create({
    data: {
      email: normalizedEmail,
      offerType: offerType || "CONVERSATION_EXPLORATOIRE",
      language: language || "FR",
      role: "CLIENT",
      expiresAt,
    },
  });

  const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3000";
  const inviteLink = `${baseUrl}/invite/${inviteToken.token}`;

  // Send welcome email
  if (process.env.SMTP_HOST) {
    try {
      const { sendInvitationEmail } = await import("@/lib/mailer");
      await sendInvitationEmail({
        to: normalizedEmail,
        firstName,
        inviteUrl: inviteLink,
        language: (language === "EN" ? "EN" : "FR") as "FR" | "EN",
      });
    } catch (err) {
      console.error("[create-client] Email error:", err);
    }
  }

  // Create kDrive folder
  try {
    const { createClientFolder, isKDriveConfigured } = await import("@/lib/kdrive");
    if (isKDriveConfigured()) {
      await createClientFolder(fullName, client.id);
    }
  } catch (err) {
    console.error("[create-client] kDrive error:", err);
  }

  // If legacy, auto-generate parcours phases
  if (isLegacy) {
    try {
      const { computePhases } = await import("@/lib/parcours");
      const phases = computePhases(clientStartDate);
      for (const phase of phases) {
        await prisma.clientPhase.create({
          data: {
            clientId: client.id,
            phaseType: phase.phaseType,
            phaseNumber: phase.phaseNumber,
            startDate: phase.startDate,
            endDate: phase.endDate,
            status: phase.status,
          },
        });
      }
    } catch (err) {
      console.error("[create-client] Parcours generation error:", err);
    }
  }

  return NextResponse.json({
    client: { id: client.id, name: fullName, email: normalizedEmail },
    inviteLink,
    isLegacy,
  }, { status: 201 });
}
