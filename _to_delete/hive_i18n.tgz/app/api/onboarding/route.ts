import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireClient, isErrorResponse } from "@/lib/api-utils";

// GET — Retourne le ClientIntake du client connecté (ou null)
export async function GET() {
  try {
    const clientResult = await requireClient();
    if (isErrorResponse(clientResult)) return clientResult;

    const client = await prisma.client.findUnique({
      where: { userId: clientResult.session.userId },
      select: { id: true },
    });

    if (!client) {
      return NextResponse.json({ intake: null });
    }

    const intake = await prisma.clientIntake.findUnique({
      where: { clientId: client.id },
    });

    return NextResponse.json({ intake: intake ?? null });
  } catch {
    return NextResponse.json(
      { error: "Erreur serveur" },
      { status: 500 }
    );
  }
}

// POST — Crée ou met à jour le ClientIntake et déclenche l'analyse
export async function POST(request: Request) {
  try {
    const clientResult = await requireClient();
    if (isErrorResponse(clientResult)) return clientResult;

    const client = await prisma.client.findUnique({
      where: { userId: clientResult.session.userId },
      select: { id: true },
    });

    if (!client) {
      return NextResponse.json(
        { error: "Profil client introuvable" },
        { status: 404 }
      );
    }

    const body = await request.json();
    const {
      firstName,
      lastName,
      birthDate,
      birthTime,
      birthPlace,
      birthCountry,
      postalAddress,
      addressLine2,
      city,
      postalCode,
      phoneNumber,
      country,
      hdType,
      intention,
    } = body;

    // Validation des champs requis
    const requiredFields = {
      firstName,
      birthDate,
      birthPlace,
      birthCountry,
      postalAddress,
      city,
      postalCode,
      country,
    };

    for (const [key, value] of Object.entries(requiredFields)) {
      if (!value || (typeof value === "string" && !value.trim())) {
        return NextResponse.json(
          { error: `Field ${key} is required` },
          { status: 400 }
        );
      }
    }

    // Upsert du ClientIntake
    await prisma.clientIntake.upsert({
      where: { clientId: client.id },
      create: {
        clientId: client.id,
        firstName: firstName.trim(),
        lastName: lastName.trim(),
        birthDate: new Date(birthDate),
        birthTime: birthTime?.trim() || null,
        birthPlace: birthPlace.trim(),
        birthCountry: birthCountry.trim(),
        postalAddress: postalAddress.trim(),
        addressLine2: addressLine2?.trim() || null,
        city: city.trim(),
        postalCode: postalCode.trim(),
        phoneNumber: phoneNumber?.trim() || null,
        country: country.trim(),
        intention: intention?.trim() || "",
        submittedAt: new Date(),
      },
      update: {
        firstName: firstName.trim(),
        lastName: lastName.trim(),
        birthDate: new Date(birthDate),
        birthTime: birthTime?.trim() || null,
        birthPlace: birthPlace.trim(),
        birthCountry: birthCountry.trim(),
        postalAddress: postalAddress.trim(),
        addressLine2: addressLine2?.trim() || null,
        city: city.trim(),
        postalCode: postalCode.trim(),
        phoneNumber: phoneNumber?.trim() || null,
        country: country.trim(),
        intention: intention?.trim() || "",
        submittedAt: new Date(),
      },
    });

    // Met à jour le flag onboardingCompleted et le type HD si renseigné
    const updatedClient = await prisma.client.update({
      where: { id: client.id },
      data: {
        onboardingCompleted: true,
        ...(hdType ? { hdType } : {}),
        birthTime: birthTime?.trim() || null,
        birthCity: birthPlace.trim(),
        birthCountry: birthCountry.trim(),
      },
      include: { user: { select: { email: true, name: true } } },
    });

    // Enrichissement via VisitorProfile (funnel tracking)
    try {
      const visitorProfile = await prisma.visitorProfile.findUnique({
        where: { email: updatedClient.user.email },
      });
      if (visitorProfile) {
        await prisma.client.update({
          where: { id: client.id },
          data: {
            acquisitionSource: visitorProfile.source || null,
            acquisitionCampaign: visitorProfile.campaign || null,
            acquisitionMedium: visitorProfile.medium || null,
            visitorProfileId: visitorProfile.id,
          },
        });
        await prisma.visitorProfile.update({
          where: { id: visitorProfile.id },
          data: { completed: true, clientId: client.id, convertedAt: new Date() },
        });
      }
    } catch {
      // Non-blocking enrichment
    }

    // Envoyer l'email PWA si pas encore envoyé
    if (!updatedClient.pwaEmailSent && process.env.SMTP_HOST) {
      try {
        const { sendPWAEmail } = await import("@/lib/mailer");
        await sendPWAEmail({
          to: updatedClient.user.email,
          firstName: firstName.trim(),
          language: (updatedClient.language === "EN" ? "EN" : "FR") as "FR" | "EN",
        });
        await prisma.client.update({
          where: { id: client.id },
          data: { pwaEmailSent: true },
        });
      } catch (err) {
        console.error("[onboarding] PWA email error:", err);
      }
    }

    // Update User name with firstName
    await prisma.user.update({
      where: { id: clientResult.session.userId },
      data: { name: firstName.trim() + (lastName ? " " + lastName.trim() : "") },
    });

    // Notification admin — onboarding terminé
    import("@/lib/notifications")
      .then(({ notifyAdmin }) => notifyAdmin({
        clientId: client.id,
        title: `Onboarding terminé : ${firstName.trim()}`,
        description: "Le client a complété son onboarding (infos personnelles + convention + vidéo).",
        urgency: "green",
      }))
      .catch(() => {});

    // Pose un cookie pour que le middleware autorise l'accès /client/*
    const response = NextResponse.json({ success: true });
    response.cookies.set("onboarding_completed", "1", {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      maxAge: 60 * 60 * 24 * 365, // 1 an
    });
    return response;
  } catch {
    return NextResponse.json(
      { error: "Erreur serveur" },
      { status: 500 }
    );
  }
}
