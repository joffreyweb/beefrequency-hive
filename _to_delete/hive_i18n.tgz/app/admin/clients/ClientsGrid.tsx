"use client";

import { useState, useMemo } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { EDITABLE_FLAG_KEYS, getDefaultsForParcoursType, type ParcoursFlags } from "@/lib/parcours-defaults";
import { getParcoursTypeForOffer } from "@/lib/offer-parcours-binding";
import { FLAG_LABELS } from "@/lib/parcours-labels";
import type { ParcoursType } from "@prisma/client";

interface SerializedClient {
  id: string;
  name: string;
  email: string;
  offerType: string;
  offerLabel: string;
  status: string;
  language: string;
  startDate: string;
  detoxStartDate?: string | null;
  requiresProgramTimeline?: boolean;
  pendingCount: number;
  isLegacy?: boolean;
  questionnaireStatus?: string | null;
}

function getInitials(name: string): string {
  return name.split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase();
}

function computeDayNumber(startDate: string): number {
  return Math.floor((Date.now() - new Date(startDate).getTime()) / 86400000) + 1;
}

// Parcours (Le Passage/timeline) terminé = plus de 103 jours depuis le début (detoxStartDate)
function isParcoursFinished(c: SerializedClient): boolean {
  if (!c.requiresProgramTimeline || !c.detoxStartDate) return false;
  const day = Math.floor((Date.now() - new Date(c.detoxStartDate).getTime()) / 86400000) + 1;
  return day > 103;
}

const ALL_FLAGS_TRUE: ParcoursFlags = {
  requiresWelcomeVideo: true,
  requiresConvention: true,
  requiresQuestionnaire: true,
  requiresPhaseVideos: true,
  requiresMorningCheckin: true,
  requiresEveningCheckin: true,
  requiresJournal: true,
  requiresProgramTimeline: true,
  requiresElixirs: true,
  requiresModules: true,
};

const DEFAULT_OFFER = "CONVERSATION_EXPLORATOIRE";

const OFFER_OPTIONS = [
  { value: "CONVERSATION_EXPLORATOIRE", label: "Conversation exploratoire priv\u00e9e" },
  { value: "SESSION_SEUIL", label: "Session Seuil" },
  { value: "LE_NECTAR_CYCLE", label: "Le Nectar Cycle (600\u20ac)" },
  { value: "LE_PASSAGE_1_1", label: "Le Passage 1:1 (3 900\u20ac)" },
  { value: "LES_CYCLES_DE_LA_RUCHE", label: "Les Cycles de la Ruche (1 200\u20ac)" },
  { value: "CEREMONIE_RESET", label: "C\u00e9r\u00e9monie Reset (150\u20ac)" },
  { value: "LA_RUCHE_VIVANTE", label: "La Ruche Vivante (75\u20ac)" },
  { value: "SOUVERAINETE", label: "Souverainet\u00e9 (15 000\u20ac)" },
  { value: "LA_CHAMBRE_DE_LA_REINE", label: "La Chambre de la Reine" },
  { value: "SOS_URGENCE_VIP", label: "SOS \u00b7 Urgence VIP" },
  { value: "LE_FIL_DE_LA_RUCHE", label: "Le Fil de la Ruche" },
  { value: "PARCOURS_PERSONNALISE", label: "Parcours personnalisé" },
];

export default function ClientsGrid({ clients }: { clients: SerializedClient[] }) {
  const router = useRouter();
  const [search, setSearch] = useState("");
  const [showInvite, setShowInvite] = useState(false);

  // Invite form state
  const [form, setForm] = useState({
    firstName: "", lastName: "", email: "",
    offerType: "CONVERSATION_EXPLORATOIRE", language: "FR",
    isLegacy: false, startDate: "", dayDirect: "",
  });
  const [creating, setCreating] = useState(false);
  const [result, setResult] = useState<{ success: boolean; message: string; link?: string } | null>(null);
  const [parcoursType, setParcoursType] = useState<ParcoursType>(getParcoursTypeForOffer(DEFAULT_OFFER));
  const [flags, setFlags] = useState<ParcoursFlags>(() => getDefaultsForParcoursType(getParcoursTypeForOffer(DEFAULT_OFFER)));
  const [parcoursFilter, setParcoursFilter] = useState<"all" | "actifs" | "termines">("all");

  // L'offre pilote le parcoursType ET les flags par défaut (comme /admin/clients/new).
  function handleOfferChange(nextOffer: string) {
    const pt = getParcoursTypeForOffer(nextOffer);
    setForm((f) => ({ ...f, offerType: nextOffer }));
    setParcoursType(pt);
    setFlags(getDefaultsForParcoursType(pt));
  }

  const filteredClients = useMemo(() => {
    let list = clients;
    if (parcoursFilter === "termines") list = list.filter(isParcoursFinished);
    else if (parcoursFilter === "actifs") list = list.filter((c) => !isParcoursFinished(c));
    if (!search.trim()) return list;
    const q = search.toLowerCase();
    return list.filter((c) => c.name.toLowerCase().includes(q) || c.email.toLowerCase().includes(q));
  }, [clients, search, parcoursFilter]);

  async function handleCreate() {
    if (!form.firstName.trim() || !form.lastName.trim() || !form.email.trim()) return;
    setCreating(true);
    setResult(null);
    try {
      const res = await fetch("/api/admin/create-client", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          firstName: form.firstName,
          lastName: form.lastName,
          email: form.email,
          offerType: form.offerType,
          language: form.language,
          isLegacy: form.isLegacy,
          startDate: form.isLegacy && form.startDate ? form.startDate : null,
          dayDirect: form.isLegacy && form.dayDirect ? Number(form.dayDirect) : null,
          parcoursType,
          ...flags,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setResult({ success: true, message: "Client cree — email envoye", link: data.inviteLink });
        setTimeout(() => router.refresh(), 2000);
      } else {
        setResult({ success: false, message: data.error || "Erreur" });
      }
    } catch {
      setResult({ success: false, message: "Erreur de connexion" });
    } finally {
      setCreating(false);
    }
  }

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <h1 className="font-display text-2xl font-light text-brun-chaud">La Ruche</h1>
        <button
          onClick={() => {
            setShowInvite(true);
            setResult(null);
            setForm({ firstName: "", lastName: "", email: "", offerType: DEFAULT_OFFER, language: "FR", isLegacy: false, startDate: "", dayDirect: "" });
            setParcoursType(getParcoursTypeForOffer(DEFAULT_OFFER));
            setFlags(getDefaultsForParcoursType(getParcoursTypeForOffer(DEFAULT_OFFER)));
          }}
          className="px-4 py-2.5 bg-or-sacre text-white font-ui text-xs uppercase tracking-wider rounded-[10px] hover:bg-ambre-vif transition-colors"
        >
          Inviter un client
        </button>
      </div>

      {/* Search */}
      <div className="mb-6">
        <input
          type="text"
          placeholder="Rechercher un client..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full max-w-sm px-4 py-2.5 bg-cire-chaude border border-or-pale rounded-[10px] text-sm font-ui text-brun-chaud placeholder:text-brun-mid/40 outline-none focus:border-or-sacre transition-colors"
        />
        <div className="mt-3 flex items-center gap-2">
          {(["all", "actifs", "termines"] as const).map((key) => {
            const label = key === "all" ? "Tous" : key === "actifs" ? "En cours" : "Termines";
            return (
              <button
                key={key}
                onClick={() => setParcoursFilter(key)}
                className={`px-3 py-1.5 text-xs font-ui rounded-full border transition-colors ${parcoursFilter === key ? "bg-or-sacre text-white border-or-sacre" : "border-or-pale text-brun-mid hover:border-or-sacre"}`}
              >
                {label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Client grid */}
      {filteredClients.length === 0 ? (
        <div className="bg-cire-chaude border border-or-pale rounded-[10px] p-8 text-center">
          <p className="text-sm text-brun-mid/60 font-ui">Aucun client trouve.</p>
        </div>
      ) : (
        <div className="grid grid-cols-3 gap-4">
          {filteredClients.map((client) => {
            const initials = getInitials(client.name);
            const dayNumber = computeDayNumber(client.startDate);

            return (
              <Link
                key={client.id}
                href={`/admin/clients/${client.id}`}
                className="bg-cire-chaude border border-or-pale rounded-[10px] p-5 hover:border-or-sacre transition-all"
              >
                <div className="w-10 h-10 rounded-full bg-or-sacre/10 flex items-center justify-center mb-3">
                  <span className="text-sm font-ui font-medium text-or-sacre">{initials}</span>
                </div>
                <div className="flex items-center justify-between">
                  <p className="font-ui text-sm text-brun-chaud">{client.name}</p>
                  <div className="flex items-center gap-1.5">
                    {client.isLegacy && (
                      <span className="text-[9px] bg-brun-mid/10 text-brun-mid px-1.5 py-0.5 rounded-full">Legacy</span>
                    )}
                    {isParcoursFinished(client) && (
                      <span className="text-[9px] bg-foret/10 text-foret px-1.5 py-0.5 rounded-full">Termine</span>
                    )}
                    {client.pendingCount > 0 && (
                      <span className="text-[10px] bg-red-500 text-white px-1.5 py-0.5 rounded-full">{client.pendingCount}</span>
                    )}
                  </div>
                </div>
                <p className="text-[10px] font-ui text-brun-mid mt-1">
                  Day {dayNumber} · {client.offerLabel} · {client.language}
                </p>
                {client.questionnaireStatus && (
                  <span className={`text-[9px] font-ui mt-1 inline-block px-1.5 py-0.5 rounded-full ${
                    client.questionnaireStatus === "SUBMITTED"
                      ? "bg-foret/10 text-foret"
                      : client.questionnaireStatus === "IN_PROGRESS"
                        ? "bg-or-sacre/10 text-or-sacre"
                        : "bg-brun-mid/10 text-brun-mid"
                  }`}>
                    Q: {client.questionnaireStatus === "SUBMITTED" ? "Soumis ✓" : client.questionnaireStatus === "IN_PROGRESS" ? "En cours" : "En attente"}
                  </span>
                )}
              </Link>
            );
          })}
        </div>
      )}

      {/* Invite Modal */}
      {showInvite && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="bg-creme-sacree border border-or-pale rounded-[10px] w-full max-w-md shadow-xl max-h-[90vh] flex flex-col">
            <h3 className="font-display text-lg text-brun-chaud px-6 pt-6 pb-4 flex-shrink-0">Inviter un client</h3>

            {result?.success ? (
              <div className="space-y-3 px-6 pb-6">
                <p className="text-sm font-ui text-foret">{result.message}</p>
                {result.link && (
                  <div className="bg-cire-chaude border border-or-pale rounded-sm p-3">
                    <p className="text-xs font-ui text-brun-mid/60 mb-1">Lien d&apos;activation</p>
                    <p className="text-xs font-ui text-foret break-all select-all">{result.link}</p>
                  </div>
                )}
                <button onClick={() => setShowInvite(false)} className="w-full py-2 bg-or-sacre text-white text-xs font-ui uppercase rounded-sharp hover:bg-ambre-vif">Fermer</button>
              </div>
            ) : (
              <>
                <div className="space-y-3 px-6 overflow-y-auto flex-1 pb-3">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-ui text-brun-mid/60 mb-1">Prenom *</label>
                    <input type="text" value={form.firstName} onChange={(e) => setForm({ ...form, firstName: e.target.value })} className="w-full px-3 py-2 bg-cire-chaude border border-or-pale rounded-sm text-sm font-ui text-brun-chaud" placeholder="Prenom" />
                  </div>
                  <div>
                    <label className="block text-xs font-ui text-brun-mid/60 mb-1">Nom *</label>
                    <input type="text" value={form.lastName} onChange={(e) => setForm({ ...form, lastName: e.target.value })} className="w-full px-3 py-2 bg-cire-chaude border border-or-pale rounded-sm text-sm font-ui text-brun-chaud" placeholder="Nom" />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-ui text-brun-mid/60 mb-1">Email *</label>
                  <input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="w-full px-3 py-2 bg-cire-chaude border border-or-pale rounded-sm text-sm font-ui text-brun-chaud" placeholder="client@email.com" />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-ui text-brun-mid/60 mb-1">Offre</label>
                    <select value={form.offerType} onChange={(e) => handleOfferChange(e.target.value)} className="w-full px-3 py-2 bg-cire-chaude border border-or-pale rounded-sm text-sm font-ui text-brun-chaud">
                      {OFFER_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-ui text-brun-mid/60 mb-1">Langue</label>
                    <select value={form.language} onChange={(e) => setForm({ ...form, language: e.target.value })} className="w-full px-3 py-2 bg-cire-chaude border border-or-pale rounded-sm text-sm font-ui text-brun-chaud">
                      <option value="FR">FR</option>
                      <option value="EN">EN</option>
                    </select>
                  </div>
                </div>

                {/* Modules actifs — 8 checkboxes libres */}
                <div className="bg-cire-chaude border border-or-pale rounded-sm p-5">
                  <p className="text-xs font-ui font-light text-brun-mid uppercase tracking-wider mb-3">
                    Modules actifs
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {EDITABLE_FLAG_KEYS.map((flag) => (
                      <label
                        key={flag}
                        className={`flex items-center gap-2 px-3 py-2 bg-creme-sacree border border-or-pale rounded-sharp text-sm font-ui cursor-pointer hover:border-or-sacre transition-colors ${creating ? "opacity-50 cursor-not-allowed" : ""}`}
                      >
                        <input
                          type="checkbox"
                          checked={flags[flag]}
                          onChange={() => setFlags({ ...flags, [flag]: !flags[flag] })}
                          disabled={creating}
                          className="accent-or-sacre"
                        />
                        <span className="text-brun-chaud">{FLAG_LABELS[flag]}</span>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Legacy toggle */}
                <div className="border-t border-or-pale/50 pt-3">
                  <label className="flex items-center gap-3 cursor-pointer">
                    <div
                      onClick={() => setForm({ ...form, isLegacy: !form.isLegacy })}
                      className={`relative w-10 h-5 rounded-full transition-colors ${form.isLegacy ? "bg-or-sacre" : "bg-brun-mid/20"}`}
                    >
                      <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform ${form.isLegacy ? "translate-x-5" : "translate-x-0.5"}`} />
                    </div>
                    <span className="text-sm font-ui text-brun-chaud">Client Legacy</span>
                  </label>
                  <p className="text-[10px] font-ui text-brun-mid/50 mt-1 ml-13">
                    Skip onboarding, entre directement en Programme 3 mois
                  </p>
                </div>

                {/* Legacy fields */}
                {form.isLegacy && (
                  <div className="bg-cire-chaude border border-or-pale/50 rounded-lg p-3 space-y-3">
                    <div>
                      <label className="block text-xs font-ui text-brun-mid/60 mb-1">Date de demarrage</label>
                      <input type="date" value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value, dayDirect: "" })} className="w-full px-3 py-2 bg-cire-chaude border border-or-pale rounded-sm text-sm font-ui text-brun-chaud" />
                    </div>
                    <div className="text-center text-xs font-ui text-brun-mid/40">ou</div>
                    <div>
                      <label className="block text-xs font-ui text-brun-mid/60 mb-1">Jour direct (ex: 15 = le client est a J15)</label>
                      <input type="number" min="1" value={form.dayDirect} onChange={(e) => setForm({ ...form, dayDirect: e.target.value, startDate: "" })} placeholder="Numero du jour" className="w-full px-3 py-2 bg-cire-chaude border border-or-pale rounded-sm text-sm font-ui text-brun-chaud" />
                    </div>
                  </div>
                )}

                {result && !result.success && (
                  <p className="text-xs font-ui text-red-600">{result.message}</p>
                )}
                </div>

                <div className="flex gap-3 justify-end px-6 py-4 border-t border-or-pale/50 flex-shrink-0">
                  <button onClick={() => setShowInvite(false)} className="px-4 py-2 border border-or-pale text-brun-mid text-xs font-ui uppercase rounded-sharp hover:bg-cire-chaude">Annuler</button>
                  <button
                    onClick={handleCreate}
                    disabled={creating || !form.firstName.trim() || !form.lastName.trim() || !form.email.trim()}
                    className="px-4 py-2 bg-or-sacre text-white text-xs font-ui uppercase rounded-sharp hover:bg-ambre-vif disabled:opacity-50"
                  >
                    {creating ? "Creation..." : "Creer le client"}
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
