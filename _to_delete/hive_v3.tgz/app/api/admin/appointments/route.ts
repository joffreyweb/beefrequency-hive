import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin, isErrorResponse } from "@/lib/api-utils";
import { createZoomMeeting, isZoomConfigured } from "@/lib/zoom";
import { createCalDAVEvent } from "@/lib/caldav";

// GET /api/admin/appointments — Tous les RDV (filtre optionnel par mois)
export async function GET(request: NextRequest) {
  const auth = await requireAdmin();
  if (isErrorResponse(auth)) return auth;

  const { searchParams } = request.nextUrl;
  const month = searchParams.get("month"); // YYYY-MM
  const clientId = searchParams.get("clientId");

  const where: Record<string, unknown> = {};
  if (month) {
    const start = new Date(`${month}-01T00:00:00`);
    const end = new Date(start);
    end.setMonth(end.getMonth() + 1);
    where.scheduledAt = { gte: start, lt: end };
  }
  if (clientId) where.clientId = clientId;

  const appointments = await prisma.appointment.findMany({
    where,
    orderBy: { scheduledAt: "asc" },
    include: { client: { include: { user: { select: { name: true, email: true } } } } },
  });

  return NextResponse.json({ appointments });
}

// POST /api/admin/appointments — Creer un RDV (+ Zoom + email)
export async function POST(request: NextRequest) {
  const auth = await requireAdmin();
  if (isErrorResponse(auth)) return auth;

  const { clientId, scheduledAt, durationMin, title, notes, sendEmail, useFromPack, meetingType } = await request.json();

  if (!clientId || !scheduledAt) {
    return NextResponse.json({ error: "clientId et scheduledAt requis" }, { status: 400 });
  }

  // Validation durée (15 ≤ x ≤ 480) + fin ≤ 23h00 Europe/Brussels
  const effectiveDuration = Number(durationMin) || 60;
  if (!Number.isFinite(effectiveDuration) || effectiveDuration < 15 || effectiveDuration > 480) {
    return NextResponse.json(
      { error: "Durée invalide (doit être entre 15 et 480 minutes)" },
      { status: 400 },
    );
  }
  const startAt = new Date(scheduledAt);
  const endAt = new Date(startAt.getTime() + effectiveDuration * 60000);
  const brusselsHour = (d: Date) =>
    parseInt(
      new Intl.DateTimeFormat("en-GB", { timeZone: "Europe/Brussels", hour: "2-digit", hour12: false }).format(d),
      10,
    );
  const brusselsMinute = (d: Date) =>
    parseInt(
      new Intl.DateTimeFormat("en-GB", { timeZone: "Europe/Brussels", minute: "2-digit" }).format(d),
      10,
    );
  const endHour = brusselsHour(endAt);
  const endMinute = brusselsMinute(endAt);
  // Fin autorisée jusqu'à 23h00 pile (23:00:00). Rejet si après.
  if (endHour > 23 || (endHour === 23 && endMinute > 0)) {
    return NextResponse.json(
      { error: "Le RDV dépasse l'amplitude (fin au-delà de 23h00)" },
      { status: 400 },
    );
  }

  const client = await prisma.client.findUnique({
    where: { id: clientId },
    include: { user: { select: { name: true, email: true } } },
  });

  if (!client) {
    return NextResponse.json({ error: "Client introuvable" }, { status: 404 });
  }

  const dateTime = startAt;
  const dur = effectiveDuration;
  const meetingTitle = title || "Session BeeFrequency";

  const type = meetingType === "presentiel" ? "presentiel" : "zoom";

  // Creer reunion Zoom (uniquement si type zoom)
  let zoomMeetingId: string | null = null;
  let zoomJoinUrl: string | null = null;
  let zoomStartUrl: string | null = null;

  if (type === "zoom" && isZoomConfigured()) {
    try {
      const zoom = await createZoomMeeting(meetingTitle, dateTime, dur);
      zoomMeetingId = zoom.meetingId;
      zoomJoinUrl = zoom.joinUrl;
      zoomStartUrl = zoom.startUrl;
    } catch (err) {
      console.error("[appointment] Zoom error:", err);
      // Continue sans Zoom
    }
  }

  // Lier au pack si demande
  let sessionPackId: string | null = null;
  if (useFromPack !== false) {
    const pack = await prisma.sessionPack.findFirst({
      where: { clientId },
      orderBy: { paidAt: "desc" },
    });
    if (pack) {
      const usedCount = await prisma.appointment.count({
        where: { sessionPackId: pack.id, status: { not: "CANCELLED" } },
      });
      // Lier seulement s'il reste des seances
      const totalAll = await prisma.sessionPack.aggregate({
        where: { clientId },
        _sum: { totalSessions: true },
      });
      const totalUsed = await prisma.appointment.count({
        where: { clientId, sessionPackId: { not: null }, status: { not: "CANCELLED" } },
      });
      if ((totalAll._sum.totalSessions || 0) > totalUsed) {
        sessionPackId = pack.id;
      }
    }
  }

  const appointment = await prisma.appointment.create({
    data: {
      clientId,
      title: meetingTitle,
      scheduledAt: dateTime,
      durationMin: dur,
      zoomMeetingId,
      zoomJoinUrl,
      zoomStartUrl,
      meetingType: type,
      notes: notes || null,
      sessionPackId,
    },
    include: { client: { include: { user: { select: { name: true, email: true } } } } },
  });

  // Push vers Radicale CalDAV
  try {
    const endTime = new Date(dateTime.getTime() + dur * 60000);
    await createCalDAVEvent({
      uid: `hive-${appointment.id}`,
      summary: `${meetingTitle} — ${client.user.name || "Client"}`,
      start: dateTime,
      end: endTime,
      description: zoomJoinUrl ? `Zoom: ${zoomJoinUrl}` : undefined,
    });
  } catch (err) {
    console.error("[appointment] CalDAV push error:", err);
  }

  // Envoyer email de confirmation
  if (sendEmail !== false && process.env.SMTP_HOST) {
    try {
      const { transporter } = await import("@/lib/mailer");
      const lang = client.language === "EN" ? "EN" : "FR";
      const dateStr = dateTime.toLocaleDateString(lang === "FR" ? "fr-FR" : "en-US", {
        weekday: "long", day: "numeric", month: "long", year: "numeric", timeZone: "Europe/Brussels",
      });
      const timeStr = dateTime.toLocaleTimeString(lang === "FR" ? "fr-FR" : "en-US", {
        hour: "2-digit", minute: "2-digit", timeZone: "Europe/Brussels",
      });

      const subject = lang === "EN"
        ? "Your session is confirmed"
        : "Ta session est confirmée";

      const firstName = client.user.name?.split(" ")[0] || "";
      const isPresential = type === "presentiel";

      let body: string;
      if (lang === "EN") {
        body = `Hello ${firstName},\n\nYour ${isPresential ? "in-person" : ""} session is confirmed:\n\nDate: ${dateStr}\nTime: ${timeStr}\nDuration: ${dur} min${!isPresential && zoomJoinUrl ? `\nJoin: ${zoomJoinUrl}` : ""}\n\nSee you soon,\nJoffrey`;
      } else {
        body = `Bonjour ${firstName},\n\nTon rendez-vous ${isPresential ? "en présentiel" : ""} est confirmé :\n\nDate : ${dateStr}\nHeure : ${timeStr}\nDurée : ${dur} min${!isPresential && zoomJoinUrl ? `\nRejoindre : ${zoomJoinUrl}` : ""}\n\nÀ bientôt,\nJoffrey`;
      }

      await transporter.sendMail({
        from: `"${process.env.FROM_NAME || "Joffrey Deleplanque"}" <${process.env.FROM_EMAIL || "admin@beefrequency.com"}>`,
        to: client.user.email,
        subject,
        text: body,
      });
    } catch (err) {
      console.error("[appointment] Email error:", err);
    }
  }

  return NextResponse.json({ appointment }, { status: 201 });
}
